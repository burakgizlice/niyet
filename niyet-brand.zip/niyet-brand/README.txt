NIYET — Brand & PWA Icon Pack
=============================
"niyet" (Turkish, from Arabic niyyah نية = intention) set in Aref Ruqaa,
an Arabic naskh calligraphic typeface, on a deep emerald squircle.

Palette
  Gradient   #17A86C -> #0E7A4D -> #085236   (theme color #0E7A4D)
  Lettering  #F6F4E9  (warm cream)
Typeface: Aref Ruqaa Bold (OFL) — github.com/google/fonts

FILES
  favicon.svg / favicon.ico   Browser tab icons
  manifest.json               PWA manifest (edit start_url/scope if not root)
  head-snippet.html           Paste into index.html <head>
  niyet-icon.svg              Master squircle icon (vector)
  niyet-maskable.svg          Master full-bleed maskable (vector)
  wordmark-cream.svg/.png     Horizontal logo for dark/green backgrounds
  wordmark-green.svg/.png     Horizontal logo for light backgrounds
  icons/
    icon-16..1024.png         Standard squircle icons
    maskable-192/512.png      Full-bleed for Android adaptive icons
    apple-touch-icon.png      180px for iOS home screen

INSTALL (Vite)
  1. Copy favicon.*, manifest.json, the icons/ folder into /public
  2. Paste head-snippet.html into index.html <head>
  3. Register a service worker so the app is installable
  4. Deploy -> on mobile: Share -> Add to Home Screen

Use wordmark-cream in the app header (on the green/dark UI). Use
wordmark-green on white surfaces (emails, docs, landing hero on light bg).
